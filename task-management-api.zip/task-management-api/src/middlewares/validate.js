const { body, param, query, validationResult } = require('express-validator');

// Handle validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map(err => ({
        field: err.path,
        message: err.msg
      }))
    });
  }
  next();
};

// Auth validation rules
const registerRules = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be 2-100 characters'),
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please provide a valid email')
    .normalizeEmail(),
  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
];

const loginRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please provide a valid email')
    .normalizeEmail(),
  body('password')
    .notEmpty().withMessage('Password is required')
];

// Task validation rules
const createTaskRules = [
  body('title')
    .trim()
    .notEmpty().withMessage('Title is required')
    .isLength({ min: 1, max: 255 }).withMessage('Title must be 1-255 characters'),
  body('description')
    .optional()
    .trim(),
  body('priority')
    .optional()
    .isIn(['NONE', 'LOW', 'MEDIUM', 'HIGH']).withMessage('Priority must be NONE, LOW, MEDIUM, or HIGH'),
  body('status')
    .optional()
    .isIn(['BACKLOG', 'TODO', 'IN-PROGRESS', 'DONE', 'CANCELLED', 'IN_VALID', 'DEPLOYED', 'COMPLETED']).withMessage('Invalid status value'),
  body('due_date')
    .optional()
    .isDate().withMessage('Due date must be a valid date (YYYY-MM-DD)')
];

const updateTaskRules = [
  param('id')
    .isInt({ min: 1 }).withMessage('Invalid task ID'),
  body('title')
    .optional()
    .trim()
    .isLength({ min: 1, max: 255 }).withMessage('Title must be 1-255 characters'),
  body('description')
    .optional()
    .trim(),
  body('priority')
    .optional()
    .isIn(['NONE', 'LOW', 'MEDIUM', 'HIGH']).withMessage('Priority must be NONE, LOW, MEDIUM, or HIGH'),
  body('status')
    .optional()
    .isIn(['BACKLOG', 'TODO', 'IN-PROGRESS', 'DONE', 'CANCELLED', 'IN_VALID', 'DEPLOYED', 'COMPLETED']).withMessage('Invalid status value'),
  body('due_date')
    .optional()
    .isDate().withMessage('Due date must be a valid date (YYYY-MM-DD)')
];

const taskIdRule = [
  param('id')
    .isInt({ min: 1 }).withMessage('Invalid task ID')
];

// Query validation for pagination/filtering
const taskQueryRules = [
  query('page')
    .optional()
    .isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('status')
    .optional()
    .isIn(['BACKLOG', 'TODO', 'IN-PROGRESS', 'DONE', 'CANCELLED', 'IN_VALID', 'DEPLOYED', 'COMPLETED']).withMessage('Invalid status'),
  query('priority')
    .optional()
    .isIn(['NONE', 'LOW', 'MEDIUM', 'HIGH']).withMessage('Invalid priority'),
  query('search')
    .optional()
    .trim()
    .isLength({ max: 100 }).withMessage('Search term too long'),
  query('sortBy')
    .optional()
    .isIn(['created_at', 'due_date', 'priority', 'status', 'title']).withMessage('Invalid sort field'),
  query('order')
    .optional()
    .isIn(['ASC', 'DESC', 'asc', 'desc']).withMessage('Order must be ASC or DESC')
];

module.exports = {
  handleValidationErrors,
  registerRules,
  loginRules,
  createTaskRules,
  updateTaskRules,
  taskIdRule,
  taskQueryRules
};
