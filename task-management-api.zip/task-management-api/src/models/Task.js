const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Task = sequelize.define('Task', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      notEmpty: {
        msg: 'Title cannot be empty'
      }
    }
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  priority: {
    type: DataTypes.ENUM('NONE', 'LOW', 'MEDIUM', 'HIGH'),
    defaultValue: 'LOW'
  },
  status: {
    type: DataTypes.ENUM('BACKLOG', 'TODO', 'IN-PROGRESS', 'DONE', 'CANCELLED', 'IN_VALID', 'DEPLOYED', 'COMPLETED'),
    defaultValue: 'TODO'
  },
  due_date: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  attachment: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: 'tasks',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

module.exports = Task;
