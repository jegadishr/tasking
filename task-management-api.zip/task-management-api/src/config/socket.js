const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

let io;

const initializeSocket = (server) => {
  io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE']
    }
  });

  // Authentication middleware for socket connections
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;

    if (!token) {
      return next(new Error('Authentication required'));
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.id;
      next();
    } catch (error) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`User ${socket.userId} connected via WebSocket`);

    // Join user's personal room for private notifications
    socket.join(`user_${socket.userId}`);

    socket.on('disconnect', () => {
      console.log(`User ${socket.userId} disconnected`);
    });
  });

  return io;
};

const getIO = () => {
  if (!io) {
    throw new Error('Socket.io not initialized');
  }
  return io;
};

// Emit task events to specific user
const emitToUser = (userId, event, data) => {
  if (io) {
    io.to(`user_${userId}`).emit(event, data);
  }
};

// Emit task created event
const emitTaskCreated = (userId, task) => {
  emitToUser(userId, 'task:created', { task });
};

// Emit task updated event
const emitTaskUpdated = (userId, task) => {
  emitToUser(userId, 'task:updated', { task });
};

// Emit task deleted event
const emitTaskDeleted = (userId, taskId) => {
  emitToUser(userId, 'task:deleted', { taskId });
};

module.exports = {
  initializeSocket,
  getIO,
  emitTaskCreated,
  emitTaskUpdated,
  emitTaskDeleted
};
