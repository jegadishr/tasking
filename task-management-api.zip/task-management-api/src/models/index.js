const sequelize = require('../config/database');
const Task = require('./Task');
const User = require('./User');
const ActivityLog = require('./ActivityLog');

// Set up associations
User.hasMany(Task, { foreignKey: 'user_id', as: 'tasks' });
Task.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

User.hasMany(ActivityLog, { foreignKey: 'user_id', as: 'activities' });
ActivityLog.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

module.exports = {
  sequelize,
  Task,
  User,
  ActivityLog
};
