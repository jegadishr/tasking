const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');
const authMiddleware = require('../middlewares/auth');
const upload = require('../config/multer');
const {
  createTaskRules,
  updateTaskRules,
  taskIdRule,
  taskQueryRules,
  handleValidationErrors
} = require('../middlewares/validate');

// Protect all task routes
router.use(authMiddleware);

// GET /api/tasks - with pagination, filtering, search
router.get('/', taskQueryRules, handleValidationErrors, taskController.getAllTasks);

// GET /api/tasks/:id
router.get('/:id', taskIdRule, handleValidationErrors, taskController.getTaskById);

// POST /api/tasks - with optional file attachment
router.post('/', upload.single('attachment'), createTaskRules, handleValidationErrors, taskController.createTask);

// PUT /api/tasks/:id
router.put('/:id', updateTaskRules, handleValidationErrors, taskController.updateTask);

// DELETE /api/tasks/:id
router.delete('/:id', taskIdRule, handleValidationErrors, taskController.deleteTask);

module.exports = router;
