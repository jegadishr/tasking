const { Op } = require('sequelize');
const { ActivityLog, User } = require('../models');

// Get all activities for logged-in user
exports.getMyActivities = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;

    const where = { user_id: req.user.id };

    // Filter by action type
    if (req.query.action) {
      where.action = req.query.action.toUpperCase();
    }

    // Filter by entity type
    if (req.query.entity_type) {
      where.entity_type = req.query.entity_type.toLowerCase();
    }

    // Filter by date range
    if (req.query.from || req.query.to) {
      where.created_at = {};
      if (req.query.from) {
        where.created_at[Op.gte] = new Date(req.query.from);
      }
      if (req.query.to) {
        where.created_at[Op.lte] = new Date(req.query.to);
      }
    }

    const { count, rows: activities } = await ActivityLog.findAndCountAll({
      where,
      order: [['created_at', 'DESC']],
      limit,
      offset
    });

    const totalPages = Math.ceil(count / limit);

    res.json({
      success: true,
      data: activities,
      pagination: {
        currentPage: page,
        totalPages,
        totalItems: count,
        itemsPerPage: limit
      }
    });
  } catch (error) {
    next(error);
  }
};

// Get activities for a specific task
exports.getTaskActivities = async (req, res, next) => {
  try {
    const { taskId } = req.params;

    const activities = await ActivityLog.findAll({
      where: {
        entity_type: 'task',
        entity_id: taskId,
        user_id: req.user.id
      },
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'name', 'email']
      }],
      order: [['created_at', 'DESC']]
    });

    res.json({
      success: true,
      data: activities
    });
  } catch (error) {
    next(error);
  }
};

// Get activity summary/stats
exports.getActivityStats = async (req, res, next) => {
  try {
    const { Op } = require('sequelize');
    const sequelize = require('../config/database');

    // Get counts by action type
    const stats = await ActivityLog.findAll({
      where: { user_id: req.user.id },
      attributes: [
        'action',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count']
      ],
      group: ['action']
    });

    // Get recent activity count (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const recentCount = await ActivityLog.count({
      where: {
        user_id: req.user.id,
        created_at: { [Op.gte]: sevenDaysAgo }
      }
    });

    res.json({
      success: true,
      data: {
        byAction: stats,
        recentActivities: recentCount
      }
    });
  } catch (error) {
    next(error);
  }
};

// Helper function to log activity (used by other controllers)
exports.logActivity = async ({ userId, action, entityType, entityId, oldValues, newValues, description, ipAddress }) => {
  try {
    await ActivityLog.create({
      user_id: userId,
      action,
      entity_type: entityType,
      entity_id: entityId,
      old_values: oldValues,
      new_values: newValues,
      description,
      ip_address: ipAddress
    });
  } catch (error) {
    console.error('Failed to log activity:', error);
  }
};
