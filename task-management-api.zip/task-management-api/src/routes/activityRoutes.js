const express = require('express');
const router = express.Router();
const activityController = require('../controllers/activityController');
const authMiddleware = require('../middlewares/auth');

// Protect all activity routes
router.use(authMiddleware);

// GET /api/activities - Get all my activities
router.get('/', activityController.getMyActivities);

// GET /api/activities/stats - Get activity statistics
router.get('/stats', activityController.getActivityStats);

// GET /api/activities/task/:taskId - Get activities for specific task
router.get('/task/:taskId', activityController.getTaskActivities);

module.exports = router;
