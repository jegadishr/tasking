const { Op } = require('sequelize');
const { Task } = require('../models');
const { emitTaskCreated, emitTaskUpdated, emitTaskDeleted } = require('../config/socket');
const { logActivity } = require('./activityController');

// Get all tasks for logged-in user with pagination, filtering, search
exports.getAllTasks = async (req, res, next) => {
  try {
    // Pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;

    // Filtering
    const where = { user_id: req.user.id };

    if (req.query.status) {
      where.status = req.query.status.toUpperCase();
    }

    if (req.query.priority) {
      where.priority = req.query.priority.toUpperCase();
    }

    // Search by title or description
    if (req.query.search) {
      where[Op.or] = [
        { title: { [Op.like]: `%${req.query.search}%` } },
        { description: { [Op.like]: `%${req.query.search}%` } }
      ];
    }

    // Sorting
    const sortBy = req.query.sortBy || 'created_at';
    const order = (req.query.order || 'DESC').toUpperCase();

    // Execute query
    const { count, rows: tasks } = await Task.findAndCountAll({
      where,
      order: [[sortBy, order]],
      limit,
      offset
    });

    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);

    res.json({
      success: true,
      data: tasks,
      pagination: {
        currentPage: page,
        totalPages,
        totalItems: count,
        itemsPerPage: limit,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      }
    });
  } catch (error) {
    next(error);
  }
};

// Get single task
exports.getTaskById = async (req, res, next) => {
  try {
    const task = await Task.findOne({
      where: { id: req.params.id, user_id: req.user.id }
    });

    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'Task not found'
      });
    }

    res.json({
      success: true,
      data: task
    });
  } catch (error) {
    next(error);
  }
};

// Create task
exports.createTask = async (req, res, next) => {
  try {
    const { title, description, priority, status, due_date } = req.body;

    // Handle file upload
    const attachment = req.file ? req.file.filename : null;

    const task = await Task.create({
      title,
      description,
      priority: priority || 'LOW',
      status: status || 'TODO',
      due_date,
      user_id: req.user.id,
      attachment
    });

    // Log activity
    await logActivity({
      userId: req.user.id,
      action: 'CREATE',
      entityType: 'task',
      entityId: task.id,
      oldValues: null,
      newValues: task.toJSON(),
      description: `Created task: ${task.title}`,
      ipAddress: req.ip
    });

    // Emit real-time event
    emitTaskCreated(req.user.id, task);

    res.status(201).json({
      success: true,
      message: 'Task created successfully',
      data: task
    });
  } catch (error) {
    next(error);
  }
};

// Update task
exports.updateTask = async (req, res, next) => {
  try {
    const { title, description, priority, status, due_date } = req.body;
    const { id } = req.params;

    const task = await Task.findOne({
      where: { id, user_id: req.user.id }
    });

    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'Task not found'
      });
    }

    // Store old values for activity log
    const oldValues = task.toJSON();

    await task.update({
      title: title || task.title,
      description: description !== undefined ? description : task.description,
      priority: priority || task.priority,
      status: status || task.status,
      due_date: due_date !== undefined ? due_date : task.due_date
    });

    // Log activity
    await logActivity({
      userId: req.user.id,
      action: 'UPDATE',
      entityType: 'task',
      entityId: task.id,
      oldValues: oldValues,
      newValues: task.toJSON(),
      description: `Updated task: ${task.title}`,
      ipAddress: req.ip
    });

    // Emit real-time event
    emitTaskUpdated(req.user.id, task);

    res.json({
      success: true,
      message: 'Task updated successfully',
      data: task
    });
  } catch (error) {
    next(error);
  }
};

// Delete task
exports.deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findOne({
      where: { id: req.params.id, user_id: req.user.id }
    });

    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'Task not found'
      });
    }

    const taskId = task.id;
    const taskData = task.toJSON();

    await task.destroy();

    // Log activity
    await logActivity({
      userId: req.user.id,
      action: 'DELETE',
      entityType: 'task',
      entityId: taskId,
      oldValues: taskData,
      newValues: null,
      description: `Deleted task: ${taskData.title}`,
      ipAddress: req.ip
    });

    // Emit real-time event
    emitTaskDeleted(req.user.id, taskId);

    res.json({
      success: true,
      message: 'Task deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};
