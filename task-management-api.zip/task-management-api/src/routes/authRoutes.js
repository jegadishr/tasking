const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authMiddleware = require('../middlewares/auth');
const { authLimiter } = require('../middlewares/rateLimiter');
const {
  registerRules,
  loginRules,
  handleValidationErrors
} = require('../middlewares/validate');

// Apply rate limiting to auth routes
router.use(authLimiter);

router.post('/register', registerRules, handleValidationErrors, authController.register);
router.post('/login', loginRules, handleValidationErrors, authController.login);
router.get('/profile', authMiddleware, authController.getProfile);

module.exports = router;
